package mypack;
public class BaseballCard{
  String name;
  int price;

  public BaseballCard(String name,  int price){
    name = name;
    price = price;
  }
}
